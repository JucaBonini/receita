<?php

namespace STSSearch\Frontend;

if (!defined('ABSPATH')) exit;

class Head
{
    public function __construct()
    {
        add_filter('document_title_parts', [$this, 'modify_title'], 99);
        add_action('wp_head', [$this, 'output_meta_description'], 1);
        add_action('wp_head', [$this, 'output_social_meta'], 5);
    }

    public function modify_title($parts)
    {
        if (is_singular()) {
            $custom_title = get_post_meta(get_the_ID(), '_sts_seo_title', true);
            if (!empty($custom_title)) {
                $parts['title'] = $custom_title;
            }
        }
        return $parts;
    }

    public function output_meta_description()
    {
        if (is_singular()) {
            $desc = get_post_meta(get_the_ID(), '_sts_seo_desc', true);
            if (!empty($desc)) {
                echo '<meta name="description" content="' . esc_attr($desc) . '">' . PHP_EOL;
            }
        }
    }

    public function output_social_meta()
    {
        if (!is_singular()) return;

        $post_id = get_the_ID();
        $title = get_post_meta($post_id, '_sts_seo_title', true) ?: get_the_title();
        $desc = get_post_meta($post_id, '_sts_seo_desc', true) ?: wp_trim_words(get_the_content(), 25);
        $thumb = get_the_post_thumbnail_url($post_id, 'full');
        $fallback_img = 'https://descomplicandoreceitas.com.br/wp-content/uploads/2026/03/logo-descomplicenado-receitas-2026.webp';

        // Robots Logic
        if (is_author() || is_date() || is_search() || is_404()) {
            echo '<meta name="robots" content="noindex, follow" />' . "\n";
        } else {
            echo '<meta name="robots" content="index, follow, max-snippet:-1, max-video-preview:-1, max-image-preview:large" />' . "\n";
        }

        echo '<!-- SEO Engine Pro Social -->' . "\n";
        echo '<meta name="google-site-verification" content="rZSdMspnsnOU9x8ZxwyvLIWfPDVoGsae1mWBZgti1PY" />' . "\n";
        echo '<meta name="msvalidate.01" content="E3BEF536136496E86D4C035E2C36E401" />' . "\n";
        echo '<meta name="pinnable" content="645852f757b84ed974209acf2794c0cd" />' . "\n";

        echo '<meta property="og:locale" content="pt_BR" />' . "\n";
        echo '<meta property="og:type" content="' . (is_singular() ? 'article' : 'website') . '" />' . "\n";
        echo '<meta property="og:title" content="' . esc_attr($title) . ' - Descomplicando Receitas" />' . "\n";
        echo '<meta property="og:description" content="' . esc_attr($desc) . '" />' . "\n";
        echo '<meta property="og:url" content="' . esc_url(get_permalink()) . '" />' . "\n";
        echo '<meta property="og:site_name" content="Descomplicando Receitas" />' . "\n";
        echo '<meta property="article:publisher" content="https://www.facebook.com/descomplicandoreceitasofic/" />' . "\n";

        $og_image = $thumb ?: $fallback_img;
        echo '<meta property="og:image" content="' . esc_url($og_image) . '" />' . "\n";
        echo '<meta property="og:image:width" content="1200" />' . "\n";
        echo '<meta property="og:image:height" content="630" />' . "\n";

        echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
        echo '<meta name="twitter:creator" content="@Desc_Receitas" />' . "\n";
        echo '<meta name="twitter:site" content="@Desc_Receitas" />' . "\n";
        echo '<meta name="twitter:label1" content="Escrito por" />' . "\n";
        echo '<meta name="twitter:data1" content="' . esc_attr(get_the_author()) . '" />' . "\n";
    }
}
